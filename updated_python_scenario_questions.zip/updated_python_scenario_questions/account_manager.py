from enum import Enum
from typing import Dict, List

class TransactionType(Enum):
    CREDIT = "CREDIT"
    DEBIT = "DEBIT"

class Account:
    def __init__(self, account_id: int, owner_name: str):
        self.account_id = account_id
        self.owner_name = owner_name

class Transaction:
    def __init__(
        self,
        transaction_id: int,
        account_id: int,
        tx_type: TransactionType,
        amount: float,          # Always positive in inputs
        timestamp_sec: int      # Unix-style seconds (monotonic for tests)
    ):
        self.transaction_id = transaction_id
        self.account_id = account_id
        self.type = tx_type
        self.amount = amount
        self.timestamp_sec = timestamp_sec

class AccountManager:
    # Candidate may only modify this class.
    def __init__(self):
        self.accounts: Dict[int, Account] = {}
        self.transactions: List[Transaction] = []

    def add_account(self, account: Account):
        self.accounts[account.account_id] = account

    def add_transaction(self, tx: Transaction):
        # Assume input transactions always refer to valid accounts
        self.transactions.append(tx)

    # Returns the current balance for the given account_id.
    def get_balance(self, account_id: int) -> float:
        balance = 0.0
        for tx in self.transactions:
            if tx.account_id == account_id:
                if tx.type == TransactionType.CREDIT:
                    balance += tx.amount
                else:
                    balance -= tx.amount
        print(balance)
        return balance

    def get_average_transaction_amount_by_account(self):
        overall_details = {}
        result = {}
        for tx in self.transactions:
            if overall_details.get(tx.account_id):
                overall_details[tx.account_id].append(tx.amount)
            else:
                overall_details[tx.account_id] = [tx.amount]
        for k, v in overall_details.items():
            result[k] = sum(v) / len(v)
        print(result)
        return result

    def get_transaction_fees(self) -> Dict[int, float]:
        fee = {}
        count = {}

        for tx in sorted(self.transactions, key=lambda x: x.timestamp_sec):
            account_id = tx.account_id
            if account_id not in count:
                count[account_id] = 0
                fee[account_id] = 0.0

            count[account_id] +=1

            if count[account_id] > 3:
                fee[account_id] += 1.0 if tx.type == TransactionType.CREDIT else 2.0
        return fee

    def get_suspicious_accounts(self) -> List[int]:
        times_by_account = {}
        for tx in self.transactions:
            if tx.type == TransactionType.DEBIT and tx.amount >= 50:
                times_by_account.setdefault(tx.account_id, []).append(tx.timestamp_sec)
        sus_id = []
        for id, t in times_by_account.items():
            t.sort()
            for i in range(len(t) - 2):
                if t[i+2] - t[i] <= 60:
                    sus_id.append(id)
        return sorted(sus_id)

# ---------------- Tests ----------------
def assert_almost(expected: float, actual: float, eps: float = 1e-4):
    assert abs(expected - actual) <= eps, f"Expected {expected}, got {actual}"

def test_get_balance_basic():
    print("Running test_get_balance_basic")
    mgr = AccountManager()
    mgr.add_account(Account(1, "Alice"))
    mgr.add_transaction(Transaction(101, 1, TransactionType.CREDIT, 100.0, 1000))
    mgr.add_transaction(Transaction(102, 1, TransactionType.DEBIT, 30.0, 1010))
    mgr.add_transaction(Transaction(103, 1, TransactionType.DEBIT, 20.0, 1020))
    mgr.add_transaction(Transaction(104, 1, TransactionType.CREDIT, 10.0, 1030))
    # Expected balance: 100 - 30 - 20 + 10 = 60
    assert_almost(60.0, mgr.get_balance(1))

def test_get_balance_multiple_accounts():
    print("Running test_get_balance_multiple_accounts")
    mgr = AccountManager()
    mgr.add_account(Account(1, "Alice"))
    mgr.add_account(Account(2, "Bob"))
    mgr.add_transaction(Transaction(201, 1, TransactionType.CREDIT, 50.0, 2000))
    mgr.add_transaction(Transaction(202, 2, TransactionType.CREDIT, 80.0, 2005))
    mgr.add_transaction(Transaction(203, 1, TransactionType.DEBIT, 10.0, 2010))
    mgr.add_transaction(Transaction(204, 2, TransactionType.DEBIT, 5.5, 2015))
    mgr.add_transaction(Transaction(205, 2, TransactionType.DEBIT, 14.5, 2020))
    # Account 1: 50 - 10 = 40
    assert_almost(40.0, mgr.get_balance(1))
    # Account 2: 80 - 5.5 - 14.5 = 60
    assert_almost(60.0, mgr.get_balance(2))

def test_get_average_transaction_amount_by_account():
    print("Running test_get_average_transaction_amount_by_account")
    mgr = AccountManager()
    mgr.add_account(Account(1, "Alice"))
    mgr.add_account(Account(2, "Bob"))
    mgr.add_account(Account(3, "Charlie"))  # no transactions
    # Account 1: 100, 30, 20, 10 => avg = 160 / 4 = 40
    mgr.add_transaction(Transaction(101, 1, TransactionType.CREDIT, 100.0, 1000))
    mgr.add_transaction(Transaction(102, 1, TransactionType.DEBIT, 30.0, 1010))
    mgr.add_transaction(Transaction(103, 1, TransactionType.DEBIT, 20.0, 1020))
    mgr.add_transaction(Transaction(104, 1, TransactionType.CREDIT, 10.0, 1030))
    # Account 2: 80, 5.5, 14.5 => avg = 100 / 3 ≈ 33.3333
    mgr.add_transaction(Transaction(201, 2, TransactionType.CREDIT, 80.0, 2005))
    mgr.add_transaction(Transaction(202, 2, TransactionType.DEBIT, 5.5, 2015))
    mgr.add_transaction(Transaction(203, 2, TransactionType.DEBIT, 14.5, 2020))
    print(mgr.get_average_transaction_amount_by_account())
    # avg = mgr.get_average_transaction_amount_by_account()
    # assert_almost(40.0, avg[1], 0.0001)
    # assert_almost(33.3333, avg[2], 0.0001)
    # # Account 3 has no transactions -> should not be present
    # assert 3 not in avg
def test_get_transaction_fees():
    print("Running test_get_transaction_fees")
    mgr = AccountManager()
    mgr.add_account(Account(1, "Alice"))
    mgr.add_account(Account(2, "Bob"))
    mgr.add_account(Account(3, "Jane"))
    # Account 1: 5 transactions
    mgr.add_transaction(Transaction(1, 1, TransactionType.CREDIT, 100.0, 1000))
    mgr.add_transaction(Transaction(2, 1, TransactionType.DEBIT, 20.0, 1010))
    mgr.add_transaction(Transaction(3, 1, TransactionType.CREDIT, 10.0, 1020))
    mgr.add_transaction(Transaction(4, 1, TransactionType.DEBIT, 5.0, 1030))   # fee: $2
    mgr.add_transaction(Transaction(5, 1, TransactionType.CREDIT, 7.0, 1040)) # fee: $1
    # Account 2: 4 transactions
    mgr.add_transaction(Transaction(6, 2, TransactionType.DEBIT, 50.0, 2000))
    mgr.add_transaction(Transaction(7, 2, TransactionType.DEBIT, 10.0, 2010))
    mgr.add_transaction(Transaction(8, 2, TransactionType.CREDIT, 20.0, 2020))
    mgr.add_transaction(Transaction(9, 2, TransactionType.DEBIT, 5.0, 2030))  # fee: $2
    # Account 3: 4 transactions (added out of order, must be sorted by timestamp)
    mgr.add_transaction(Transaction(26, 3, TransactionType.DEBIT, 50.0, 2000))
    mgr.add_transaction(Transaction(27, 3, TransactionType.DEBIT, 10.0, 2010))
    mgr.add_transaction(Transaction(28, 3, TransactionType.CREDIT, 20.0, 2020))  # should be 4th → $1
    mgr.add_transaction(Transaction(29, 3, TransactionType.DEBIT, 5.0, 2005))
    fees = mgr.get_transaction_fees()
    print(fees)
    # Account 1: $2 + $1 = $3
    assert_almost(3.0, fees[1], 0.0001)
    # Account 2: $2
    assert_almost(2.0, fees[2], 0.0001)
    # Account 3: 4th transaction (chronologically) is CREDIT → $1
    assert_almost(1.0, fees[3])
def test_get_suspicious_accounts():
    print("Running test_get_suspicious_accounts")
    mgr = AccountManager()
    mgr.add_account(Account(1, "Alice"))
    mgr.add_account(Account(2, "Bob"))
    mgr.add_account(Account(3, "Charlie"))
    # Account 1: three large debits within 60 seconds -> suspicious
    mgr.add_transaction(Transaction(1, 1, TransactionType.DEBIT, 50.0, 1000))
    mgr.add_transaction(Transaction(2, 1, TransactionType.DEBIT, 70.0, 1030))
    mgr.add_transaction(Transaction(3, 1, TransactionType.DEBIT, 90.0, 1060))  # inclusive window
    # Account 2: large debits but spread out -> NOT suspicious
    mgr.add_transaction(Transaction(4, 2, TransactionType.DEBIT, 60.0, 2000))
    mgr.add_transaction(Transaction(5, 2, TransactionType.DEBIT, 80.0, 2070))
    mgr.add_transaction(Transaction(6, 2, TransactionType.DEBIT, 55.0, 2141))
    # Account 3: credits + small debits -> NOT suspicious
    mgr.add_transaction(Transaction(7, 3, TransactionType.CREDIT, 1000.0, 3000))
    mgr.add_transaction(Transaction(8, 3, TransactionType.DEBIT, 49.99, 3010))
    mgr.add_transaction(Transaction(9, 3, TransactionType.DEBIT, 50.0, 3020))
    mgr.add_transaction(Transaction(10, 3, TransactionType.DEBIT, 50.0, 3100))
    print(mgr.get_suspicious_accounts())
    # print("Inside")
    # suspicious = mgr.get_suspicious_accounts()
    # assert suspicious == [1]
    # # Second test: shuffled input order
    # mgr = AccountManager()
    # mgr.add_account(Account(10, "Daisy"))
    # mgr.add_transaction(Transaction(100, 10, TransactionType.DEBIT, 50.0, 500))
    # mgr.add_transaction(Transaction(101, 10, TransactionType.DEBIT, 50.0, 560))
    # mgr.add_transaction(Transaction(102, 10, TransactionType.DEBIT, 50.0, 530))  # out of order
    # suspicious = mgr.get_suspicious_accounts()
    # assert suspicious == [10]

if __name__ == "__main__":
    # test_get_balance_basic()
    # test_get_balance_multiple_accounts()
    # test_get_average_transaction_amount_by_account()
    test_get_transaction_fees()
    # test_get_suspicious_accounts()
    # print("All tests passed.")