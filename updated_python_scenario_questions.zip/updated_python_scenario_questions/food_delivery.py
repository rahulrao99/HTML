"""
CHALLENGE: FOOD DELIVERY PLATFORM MANAGEMENT

DESCRIPTION:
We are building a program to manage a food delivery platform. The platform
tracks orders as they move through various stages:
PLACED → PREPARING → OUT_FOR_DELIVERY → DELIVERED (or CANCELED).

-------------------------------------------------------------------------------
TASK 1: BUG FIX (Statistics)
The 'get_order_statistics()' method should return a DICTIONARY with:
- "total_orders": All orders in the system.
- "active_orders": Orders with status PLACED, PREPARING, or OUT_FOR_DELIVERY.
- "closed_orders": Orders with status DELIVERED or CANCELED.
Currently, the logic is missing. Implement it.
-------------------------------------------------------------------------------
TASK 2: REVENUE PER RESTAURANT
Implement 'get_revenue_per_restaurant()'.
- This should return a dictionary: {restaurant_id: total_revenue}.
- ONLY 'DELIVERED' orders should count toward revenue.
- Canceled or active orders must be ignored.
-------------------------------------------------------------------------------
TASK 3: CUSTOMER DISTANCE ANALYTICS
Implement 'get_average_delivery_distance_per_customer()'.
- Return a dictionary: {customer_id: average_distance}.
- ONLY 'DELIVERED' orders should be included in the average.
- If a customer has no delivered orders, they should not be in the result.
-------------------------------------------------------------------------------
TASK 4: HIGHLY ACTIVE CUSTOMERS
Implement 'get_highly_active_customers()'.
- Return a sorted list of customer IDs who have placed 3 or MORE orders
  in total (any status, including CANCELED).
-------------------------------------------------------------------------------
"""

import unittest
from enum import Enum
from typing import List, Dict, Any


class OrderStatus(Enum):
    PLACED = 1
    PREPARING = 2
    OUT_FOR_DELIVERY = 3
    DELIVERED = 4
    CANCELED = 5


class Order:
    def __init__(self, order_id: int, restaurant_id: int, customer_id: int,
                 order_value: float, distance_km: float, status: OrderStatus):
        self.order_id = order_id
        self.restaurant_id = restaurant_id
        self.customer_id = customer_id
        self.order_value = order_value
        self.distance_km = distance_km
        self.status = status


class OrderManager:
    def __init__(self):
        self.orders: List[Order] = []

    def add_order(self, order: Order):
        self.orders.append(order)

    def update_order_status(self, order_id: int, new_status: OrderStatus):
        for o in self.orders:
            if o.order_id == order_id:
                o.status = new_status
                return

    def get_order_statistics(self) -> Dict[str, int]:
        """
        TASK 1: Return a dict with 'total_orders', 'active_orders', 'closed_orders'.
        """
        active_statuses = {
            OrderStatus.PLACED,
            OrderStatus.PREPARING,
            OrderStatus.OUT_FOR_DELIVERY,
        }
        closed_statuses = {OrderStatus.DELIVERED, OrderStatus.CANCELED}

        total_orders = len(self.orders)
        active_orders = sum(1 for o in self.orders if o.status in active_statuses)
        closed_orders = sum(1 for o in self.orders if o.status in closed_statuses)

        return {
            "total_orders": total_orders,
            "active_orders": active_orders,
            "closed_orders": closed_orders,
        }

    def get_revenue_per_restaurant(self) -> Dict[int, float]:
        """TASK 2: Calculate total revenue (Delivered only) per restaurant."""
        revenue: Dict[int, float] = {}
        for o in self.orders:
            if o.status == OrderStatus.DELIVERED:
                revenue[o.restaurant_id] = revenue.get(o.restaurant_id, 0.0) + o.order_value
        return revenue

    def get_average_delivery_distance_per_customer(self) -> Dict[int, float]:
        """TASK 3: Calculate average distance (Delivered only) per customer."""
        totals: Dict[int, float] = {}
        counts: Dict[int, int] = {}

        for o in self.orders:
            if o.status == OrderStatus.DELIVERED:
                totals[o.customer_id] = totals.get(o.customer_id, 0.0) + o.distance_km
                counts[o.customer_id] = counts.get(o.customer_id, 0) + 1

        return {customer_id: totals[customer_id] / counts[customer_id] for customer_id in totals}

    def get_highly_active_customers(self) -> List[int]:
        """TASK 4: Find customers with 3+ total orders (Sorted list)."""
        order_counts: Dict[int, int] = {}
        for o in self.orders:
            order_counts[o.customer_id] = order_counts.get(o.customer_id, 0) + 1

        return sorted([customer_id for customer_id, count in order_counts.items() if count >= 3])


# --- UNIT TEST SUITE ---

class TestOrderManagement(unittest.TestCase):

    def setUp(self):
        self.om = OrderManager()

    def test_task1_statistics(self):
        self.om.add_order(Order(1, 10, 100, 20.0, 1.0, OrderStatus.PLACED))  # Active
        self.om.add_order(Order(2, 10, 100, 30.0, 2.0, OrderStatus.PREPARING))  # Active
        self.om.add_order(Order(3, 11, 101, 15.0, 5.0, OrderStatus.DELIVERED))  # Closed
        self.om.add_order(Order(4, 11, 101, 15.0, 5.0, OrderStatus.CANCELED))  # Closed

        stats = self.om.get_order_statistics()

        # Verify dictionary structure and values
        self.assertIsInstance(stats, dict)
        self.assertEqual(stats["total_orders"], 4)
        self.assertEqual(stats["active_orders"], 2)
        self.assertEqual(stats["closed_orders"], 2)

    def test_task2_revenue(self):
        # Restaurant 10: 50.0 total delivered
        self.om.add_order(Order(1, 10, 100, 20.0, 1.0, OrderStatus.DELIVERED))
        self.om.add_order(Order(2, 10, 101, 30.0, 2.0, OrderStatus.DELIVERED))
        # Restaurant 11: Ignore placed/canceled
        self.om.add_order(Order(3, 11, 102, 100.0, 1.0, OrderStatus.PLACED))
        self.om.add_order(Order(4, 11, 103, 100.0, 1.0, OrderStatus.CANCELED))

        rev = self.om.get_revenue_per_restaurant()
        self.assertEqual(rev.get(10), 50.0)
        self.assertEqual(rev.get(11, 0), 0)

    def test_task3_distance(self):
        # Customer 100: (2.0 + 4.0) / 2 = 3.0
        self.om.add_order(Order(1, 1, 100, 10.0, 2.0, OrderStatus.DELIVERED))
        self.om.add_order(Order(2, 1, 100, 10.0, 4.0, OrderStatus.DELIVERED))
        # Customer 101: Ignore CANCELED
        self.om.add_order(Order(3, 1, 101, 10.0, 10.0, OrderStatus.CANCELED))

        dist = self.om.get_average_delivery_distance_per_customer()
        self.assertAlmostEqual(dist[100], 3.0)
        self.assertNotIn(101, dist)

    def test_task4_active_customers(self):
        # Customer 5: 3 orders
        self.om.add_order(Order(1, 1, 5, 10.0, 1.0, OrderStatus.PLACED))
        self.om.add_order(Order(2, 1, 5, 10.0, 1.0, OrderStatus.DELIVERED))
        self.om.add_order(Order(3, 1, 5, 10.0, 1.0, OrderStatus.CANCELED))
        # Customer 2: 2 orders
        self.om.add_order(Order(4, 1, 2, 10.0, 1.0, OrderStatus.PLACED))
        self.om.add_order(Order(5, 1, 2, 10.0, 1.0, OrderStatus.PLACED))

        active = self.om.get_highly_active_customers()
        self.assertEqual(active, [5])


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestOrderManagement)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)