from enum import Enum
import unittest
import math


class MembershipStatus(Enum):
    """
    Membership Status is of three types: BRONZE, SILVER and GOLD.
    BRONZE is the default membership a new member gets.
    SILVER and GOLD are paid memberships for the gym.
    """
    BRONZE = 1
    SILVER = 2
    GOLD = 3


class Workout:
    """
    This class represents a single workout session for a member.
    Each object of the Workout class has a unique ID, as well as
    a start time and end time that are represented in the number
    of minutes spent from the start of the day.
    """

    def __init__(self, id: int, start_time: int, end_time: int):
        self.id = id
        self.start_time = start_time
        self.end_time = end_time

    def get_duration(self):
        return self.end_time - self.start_time


class Member:
    """ Data about a gym member. """

    def __init__(self, member_id: int, name: str, membership_status: MembershipStatus):
        self.member_id = member_id
        self.name = name
        self.membership_status = membership_status

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return (
                self.member_id == other.member_id
                and self.name == other.name
                and self.membership_status == other.membership_status
        )

    def __str__(self):
        return f"Member ID: {self.member_id}, Name: {self.name}, Membership Status: {self.membership_status}"


class Membership:
    """
    Data for managing a gym membership, and methods which staff can
    use to perform any queries or updates.
    """

    def __init__(self):
        self.members = []
        self.workouts = {}

    def add_member(self, member: Member):
        """Adds a member to the gym"""
        self.members.append(member)

    def update_membership(self, member_id: int, membership_status: MembershipStatus):
        """Update membership of the given member"""
        for member in self.members:
            if member.member_id == member_id:
                member.membership_status = membership_status
                break

    def get_membership_statistics(self):
        """Calculates and returns membership statistics for all members"""
        total_members = len(self.members)
        total_paid_members_gold = sum(1 for member in self.members if member.membership_status == MembershipStatus.GOLD)
        total_paid_members_silver = sum(
            1 for member in self.members if member.membership_status == MembershipStatus.SILVER)
        total_paid_members = total_paid_members_gold + total_paid_members_silver
        conversion_rate = (total_paid_members / total_members) * 100
        return {
            "total_members": total_members,
            "total_paid_members": total_paid_members,
            "conversion_rate": conversion_rate
        }

    def add_workout(self, member_id, workout):
        exist_member = any(member.member_id == member_id for member in self.members)
        if exist_member:
            if member_id not in self.workouts:
                self.workouts[member_id] = []
            self.workouts[member_id].append(workout)

    def get_average_workout_durations(self):
        avg_du = {}
        for member in self.members:
            member_id = member.member_id
            all_workouts = self.workouts.get(member_id, [])
            if all_workouts:
                total = sum(w.get_duration() for w in all_workouts)
                avg = total / len(all_workouts)
                avg_du[member_id] = avg
            else:
                avg_du[member_id] = 0
        return avg_du

    def get_due_payments(self):
        due_payments = {}
        for member in self.members:
            member_id = member.member_id
            all_workouts = self.workouts.get(member_id, [])
            if not all_workouts:
                due_payments[member_id] = 0.0
            # 1 3 5
            # 10 8 6
            sorted_workouts = sorted(all_workouts, key=lambda r: r.id)

            if member.membership_status == MembershipStatus.BRONZE:
                free_trail = 1
                rate_per_hr = 10
            elif member.membership_status == MembershipStatus.SILVER:
                free_trail = 3
                rate_per_hr = 8
            elif member.membership_status == MembershipStatus.GOLD:
                free_trail = 5
                rate_per_hr = 6
            else:
                free_trail = 0
                rate_per_hr = 0

            total_payment = 0
            for i, t in enumerate(sorted_workouts):
                if i < free_trail:
                    continue
                total_min = t.get_duration()
                total_hr = math.ceil(total_min / 60.0)
                total = total_hr * rate_per_hr
                total_payment += total
            due_payments[member_id] = total_payment
        return due_payments


class TestSuite(unittest.TestCase):
    """ This is not a complete test suite, but tests some basic functionality of
        the code and shows how to use it.
    """

    def test_member(self):
        """Test Bronze Member functionality"""
        test_member = Member(1, "John Doe", MembershipStatus.BRONZE)
        self.assertEqual(test_member.member_id, 1)
        self.assertEqual(test_member.name, "John Doe")
        self.assertEqual(test_member.membership_status, MembershipStatus.BRONZE)

    def test_membership(self):
        test_membership = Membership()
        test_member = Member(1, "John Doe", MembershipStatus.BRONZE)
        test_membership.add_member(test_member)
        self.assertEqual(len(test_membership.members), 1)
        self.assertEqual(test_membership.members[0], test_member)

        test_membership.update_membership(1, MembershipStatus.SILVER)
        self.assertEqual(test_membership.members[0].membership_status, MembershipStatus.SILVER)

        test_member_2 = Member(2, "Alex C", MembershipStatus.BRONZE)
        test_membership.add_member(test_member_2)

        test_member_3 = Member(3, "Marie C", MembershipStatus.GOLD)
        test_membership.add_member(test_member_3)

        test_member_4 = Member(4, "Joe D", MembershipStatus.SILVER)
        test_membership.add_member(test_member_4)

        test_member_5 = Member(5, "June R.", MembershipStatus.BRONZE)
        test_membership.add_member(test_member_5)

        test_member_6 = Member(6, "Westley D.", MembershipStatus.SILVER)
        test_membership.add_member(test_member_6)

        attendance_stats = test_membership.get_membership_statistics()
        self.assertEqual(attendance_stats["total_members"], 6)
        self.assertEqual(attendance_stats["total_paid_members"], 4)
        self.assertAlmostEqual(attendance_stats["conversion_rate"], 66.67, 1)

    def test_get_average_workout_durations(self):
        """Test add_workout and get_average_workout_durations functions"""
        test_membership = Membership()
        test_member = Member(12, "John Doe", MembershipStatus.SILVER)
        test_membership.add_member(test_member)

        test_member_2 = Member(22, "Alex Cleeve", MembershipStatus.BRONZE)
        test_membership.add_member(test_member_2)

        test_member_3 = Member(31, "Marie Cardiff", MembershipStatus.GOLD)
        test_membership.add_member(test_member_3)

        test_member_4 = Member(37, "George Costanza", MembershipStatus.SILVER)
        test_membership.add_member(test_member_4)

        test_workout_1 = Workout(11, 10, 20)
        test_workout_2 = Workout(24, 15, 35)
        test_workout_3 = Workout(32, 45, 90)
        test_workout_4 = Workout(47, 100, 155)
        test_workout_5 = Workout(56, 120, 200)
        test_workout_6 = Workout(62, 300, 400)
        test_workout_7 = Workout(78, 1000, 1010)
        test_workout_8 = Workout(80, 1010, 1045)

        test_membership.add_workout(12, test_workout_1)
        test_membership.add_workout(22, test_workout_2)
        test_membership.add_workout(31, test_workout_3)
        test_membership.add_workout(12, test_workout_4)
        test_membership.add_workout(22, test_workout_5)
        test_membership.add_workout(31, test_workout_6)
        test_membership.add_workout(12, test_workout_7)
        test_membership.add_workout(4, test_workout_8)

        average_durations = test_membership.get_average_workout_durations()
        self.assertAlmostEqual(average_durations[12], 25.0, 1)
        self.assertAlmostEqual(average_durations[22], 50.0, 1)
        self.assertAlmostEqual(average_durations[31], 72.5, 1)
        self.assertNotIn(4, average_durations.keys())

    def test_get_due_payments(self):
        """Test get_due_payments function"""
        test_membership = Membership()
        test_membership.add_member(Member(1, "John Doe", MembershipStatus.BRONZE))
        test_membership.add_member(Member(2, "Alex C", MembershipStatus.SILVER))
        test_membership.add_member(Member(3, "Marie C", MembershipStatus.GOLD))

        # Add workouts for members
        member_workouts = {
            1: [Workout(1, 500, 700), Workout(10, 300, 350), Workout(12, 10, 20), Workout(3, 50, 90),
                Workout(6, 130, 150), Workout(15, 900, 920)],
            2: [Workout(13, 510, 540), Workout(14, 600, 700), Workout(2, 15, 35), Workout(4, 100, 155),
                Workout(18, 200, 225), Workout(8, 1050, 1155)],
            3: [Workout(5, 120, 135), Workout(17, 140, 190), Workout(9, 210, 255), Workout(11, 400, 450),
                Workout(16, 910, 940), Workout(7, 1000, 1100)]
        }
        for member_id, member_workout_list in member_workouts.items():
            for workout in member_workout_list:
                test_membership.add_workout(member_id, workout)

        due_payments = test_membership.get_due_payments()
        self.assertAlmostEqual(due_payments[1], 50, 1)
        self.assertAlmostEqual(due_payments[2], 32, 1)
        self.assertAlmostEqual(due_payments[3], 6, 1)

        # Test member with no workouts
        test_membership.add_member(Member(4, "Ron Burgundy", MembershipStatus.SILVER))
        due_payments = test_membership.get_due_payments()
        self.assertAlmostEqual(due_payments[4], 0, 1)

    def test_get_gym_buddies(self):
        """Test the get_gym_buddies function"""
        test_membership = Membership()

        members = [
            Member(1, "John Doe", MembershipStatus.SILVER),
            Member(2, "Alex C", MembershipStatus.BRONZE),
            Member(3, "Marie C", MembershipStatus.GOLD),
            Member(4, "Jane Smith", MembershipStatus.BRONZE),
        ]
        for member in members:
            test_membership.add_member(member)

        test_membership.add_workout(1, Workout(1, 10, 20))
        test_membership.add_workout(2, Workout(2, 15, 60))
        test_membership.add_workout(3, Workout(3, 50, 90))
        test_membership.add_workout(1, Workout(4, 100, 155))
        test_membership.add_workout(2, Workout(5, 120, 200))
        test_membership.add_workout(3, Workout(6, 300, 400))
        test_membership.add_workout(4, Workout(7, 380, 410))

        suggested_buddies = test_membership.get_gym_buddies()
        expected_values = {
            1: [(2, 40)],
            2: [(1, 40), (3, 10)],
            3: [(4, 20), (2, 10)],
            4: [(3, 20)]
        }
        for key, value in expected_values.items():
            self.assertEqual(suggested_buddies.get(key), value)

        # Second test case
        test_membership = Membership()
        members = [
            Member(1, "John Doe", MembershipStatus.SILVER),
            Member(2, "Alex C", MembershipStatus.BRONZE),
            Member(3, "Marie C", MembershipStatus.GOLD),
            Member(4, "Jane Smith", MembershipStatus.BRONZE),
            Member(5, "Sarah Johnson", MembershipStatus.SILVER),
            Member(6, "David Brown", MembershipStatus.BRONZE),
            Member(7, "Emily Davis", MembershipStatus.GOLD),
            Member(8, "Michael Wilson", MembershipStatus.BRONZE),
            Member(9, "Olivia Taylor", MembershipStatus.SILVER),
            Member(10, "Daniel Lee", MembershipStatus.BRONZE)
        ]
        for member in members:
            test_membership.add_member(member)

        workouts = [
            Workout(i, j, k)
            for i, (j, k) in enumerate(
                [
                    (10, 20), (15, 35), (50, 90), (100, 155), (110, 120),
                    (300, 400), (2000, 2010), (30, 70), (60, 80), (150, 180),
                    (250, 260), (310, 330), (370, 390), (5, 25), (190, 210),
                    (220, 230), (240, 270), (320, 350), (380, 395), (400, 410)
                ]
            )
        ]

        member_workouts = {
            1: [workouts[0], workouts[17]],
            2: [workouts[4], workouts[9], workouts[14]],
            3: [workouts[5]],
            4: [workouts[6], workouts[11]],
            5: [workouts[13], workouts[18]],
            6: [workouts[19]],
            7: [workouts[1], workouts[10], workouts[15]],
            8: [workouts[2], workouts[16]],
            9: [workouts[3], workouts[7], workouts[12]],
            10: [workouts[8]]
        }

        for member_id, member_workout_list in member_workouts.items():
            for workout in member_workout_list:
                test_membership.add_workout(member_id, workout)

        # Test gym buddies
        suggested_buddies = test_membership.get_gym_buddies()
        expected_values = {
            1: [(3, 30), (4, 10), (5, 10), (7, 5)],
            2: [(9, 15)],
            3: [(1, 30), (4, 20), (9, 20), (5, 15)],
            4: [(3, 20), (1, 10)],
            5: [(3, 15), (1, 10), (7, 10), (9, 10)],
            6: [],
            7: [(5, 10), (8, 10), (1, 5), (9, 5)],
            8: [(9, 20), (10, 20), (7, 10)],
            9: [(3, 20), (8, 20), (2, 15), (5, 10), (10, 10), (7, 5)],
            10: [(8, 20), (9, 10)]
        }
        for key, value in expected_values.items():
            self.assertEqual(suggested_buddies.get(key), value)


if __name__ == "__main__":
    unittest.main()