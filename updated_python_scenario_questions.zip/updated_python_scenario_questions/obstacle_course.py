import itertools
import secrets
import unittest
from datetime import date


class Course:
    """Data about a particular course."""

    def __init__(self, title, obstacle_count):
        self.title = title  # String, the name of the obstacle course
        self.obstacle_count = obstacle_count  # int, number of obstacles in course

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return (self.title == other.title and self.obstacle_count == other.obstacle_count)


class Run:
    """Data and methods about a single run of a course."""

    def __init__(self, course):
        self.course = course  # Course object
        self.complete = False  # True if run includes all obstacles
        self.obstacle_times = []  # list[int], times per obstacle in order

    def add_obstacle_time(self, obstacle_time):
        """
        When an obstacle is completed, add the time to the current run.
        obstacle_time: int, time in seconds it took to complete the obstacle
        """
        if self.complete:
            raise ValueError("Cannot add obstacle to complete run")
        self.obstacle_times.append(obstacle_time)
        if len(self.obstacle_times) == self.course.obstacle_count:
            self.complete = True

    def get_run_time(self):
        """
        Returns the total time this run has taken so far.
        If the run is not complete, returns time so far.
        """
        return sum(self.obstacle_times)


class RunCollection(object):
    """
    Data for a number of runs of a particular course, and methods for getting
    useful statistics about all runs of a course.
    """

    def __init__(self, course):
        self.runs = []  # list of Run objects
        self.course = course  # Course this RunCollection is for

    def get_num_runs(self):
        """Returns the number of Runs in this Collection."""
        return len(self.runs)

    def add_run(self, run):
        """Adds a Run to this RunCollection."""
        if run.course != self.course:
            raise ValueError("Run's Course is not the same as the RunCollection's")
        self.runs.append(run)

    # def personal_best(self):
    #     """Return the best finish time achieved in this RunCollection."""
    #     personal_best = []
    #     for run in self.runs:
    #         if run.complete:
    #             personal_best.append(run.get_run_time())
    #     personal_best = sorted(personal_best)[0]
    #     return personal_best

    def personal_best(self):
        """Return the best finish time achieved in this RunCollection."""
        return min(run.get_run_time() for run in self.runs)

    # def best_of_bests(self):
    #     """
    #     Returns the sum of the fastest observed time for each obstacle index
    #     across all runs (including incomplete ones).
    #     """
    #     n = self.course.obstacle_count
    #     total_time = [run.obstacle_times[:n] for run in self.runs]
    #     print(total_time)
    #     columns = itertools.zip_longest(*total_time, fillvalue=None)
    #     print(columns)
    #     best_per_obstacle = []
    #     for col in columns:
    #         observed = [t for t in col if t is not None]
    #         print("observed:", observed)
    #         if observed:
    #             best_per_obstacle.append(min(observed))
    #         if len(best_per_obstacle) == n:
    #             break
    #     if len(best_per_obstacle) != n:
    #         raise ValueError("Insufficient obstacle data to compute best_of_bests")
    #     return sum(best_per_obstacle)

    def best_of_best(self):
        obstace_count = self.course.obstacle_count
        best_times = [float('inf')] * obstace_count // ['inf', 'inf', 'inf', 'inf']
        for run in self.runs:
            for i, time in enumerate(run.obstacle_times):
                best_times[i] = min(best_times[i], time)
        print(best_times)
        return sum(best_times)

    def chance_of_personal_best(self, current_run):
        trials = 10000
        n = self.course.obstacle_count // 4

        # Personal best = minimum total among COMPLETED runs
        completed_times = [r.get_run_time() for r in self.runs if r.complete] [11, 11]
        # if not completed_times:
        #     return 1.0  # no prior PB to beat
        pb = min(completed_times) //11

        # Build pools of observed times for each obstacle index (includes incomplete runs)
        pools = [[] for _ in range(n)]
        for r in self.runs:
            if r is current_run:
                continue
            for i, t in enumerate(r.obstacle_times):
                if i < n:
                    pools[i].append(t)
        [[3, 3, 5], [3,3, 5], [2,3,2], [3,2]]
        print(pools)
        print("pools")
        start = len(current_run.obstacle_times) // 2
        # if start > n:
        #     return 0.0
        # if start == n:
        #     return 1.0 if current_run.get_run_time() <= pb else 0.0

        # If any missing obstacle has no historical data, we can't simulate it
        # for i in range(start, n):
        #     if not pools[i]:
        #         return 0.0

        base = current_run.get_run_time() // 6

        wins = 0
        for _ in range(trials):
            total = base
            for i in range(start, n):
                total += secrets.choice(pools[i])
            if total <= pb:  # meet OR beat
                wins += 1

        return wins / trials


class TestSuite(unittest.TestCase):
    def test_run(self):
        """Test basic Run functionality."""
        test_course = Course("Test course", 2)
        test_run = Run(test_course)
        test_run.add_obstacle_time(3)
        self.assertFalse(test_run.complete)
        test_run.add_obstacle_time(5)
        self.assertTrue(test_run.complete)
        self.assertEqual(test_run.obstacle_times, [3, 5])
        self.assertEqual(test_run.get_run_time(), 8)
        with self.assertRaises(ValueError):
            test_run.add_obstacle_time(4)

    def make_run_collection(self, course, obstacle_data):
        run_collection = RunCollection(course)
        for run_data in obstacle_data:
            run = Run(course)
            for obstacle_time in run_data:
                run.add_obstacle_time(obstacle_time)
            run_collection.add_run(run)
        return run_collection

    def test_run_collection(self):
        obstacle_data = [
            [3, 4, 5, 6],
            [4, 4, 4, 5],
            [4, 5, 4, 6],
            [5, 5, 3],
        ]
        test_course = Course("Test course", 4)
        run_collection = self.make_run_collection(test_course, obstacle_data)
        print(run_collection.best_of_best())
        # self.assertEqual(run_collection.get_num_runs(), len(obstacle_data))
        self.assertEqual(run_collection.personal_best(), 17)

        # New test for best_of_bests (uses incomplete run's 3 on obstacle 3)
        self.assertEqual(run_collection.best_of_best(), 15)

    def test_chance_of_personal_best(self):
        obstacle_data = [[3, 3, 2, 3],
                         [3, 3, 3, 2],
                         [5, 5, 2]]
        test_course = Course("Test Course", 4)
        run_collection = self.make_run_collection(test_course, obstacle_data)
        test_run = Run(test_course)
        test_run.add_obstacle_time(3)
        test_run.add_obstacle_time(3)
        chance = run_collection.chance_of_personal_best(test_run)
        self.assertTrue(0.81333 <= chance <= 0.85333)


if __name__ == "__main__":
    unittest.main()
